package com.company;

public class Main {
    
    public static void main(String[] args) {
        // write your code here
        String s = "voldikss";
        switch (s) {
            case "voldikss":
                System.out.println("yes");
                break;
            default:
                System.out.println("no");
                break;
        }
    }
}
